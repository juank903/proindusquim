<?php

function get_layout_positions()
{
    return array(
        'header' => array(),
        'sidebar' => array(),
        'footer' => array()
    );
}

?>
