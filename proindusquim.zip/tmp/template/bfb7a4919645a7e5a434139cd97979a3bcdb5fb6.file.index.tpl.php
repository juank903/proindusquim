<?php /* Smarty version Smarty-3.1.8, created on 2012-11-03 14:26:11
         compiled from "/var/www/mvc-twb/views/index/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1693514971509561c3943184-81506609%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bfb7a4919645a7e5a434139cd97979a3bcdb5fb6' => 
    array (
      0 => '/var/www/mvc-twb/views/index/index.tpl',
      1 => 1335100144,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1693514971509561c3943184-81506609',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_509561c394a5b3_33716906',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_509561c394a5b3_33716906')) {function content_509561c394a5b3_33716906($_smarty_tpl) {?>Hola desde la vista smarty...<?php }} ?>