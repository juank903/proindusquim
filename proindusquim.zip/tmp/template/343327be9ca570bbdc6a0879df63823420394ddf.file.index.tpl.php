<?php /* Smarty version Smarty-3.1.8, created on 2012-11-06 13:48:01
         compiled from "C:\xampp\htdocs\mvc-twb\views\index\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2076050990701d5b9c0-10529148%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '343327be9ca570bbdc6a0879df63823420394ddf' => 
    array (
      0 => 'C:\\xampp\\htdocs\\mvc-twb\\views\\index\\index.tpl',
      1 => 1335100144,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2076050990701d5b9c0-10529148',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_50990701d5d822_12961489',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_50990701d5d822_12961489')) {function content_50990701d5d822_12961489($_smarty_tpl) {?>Hola desde la vista smarty...<?php }} ?>