<?php /* Smarty version Smarty-3.1.8, created on 2014-05-27 06:27:37
         compiled from "/var/www/mvc2/views/index/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:232487559538476a90c2651-32607364%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7dbf0189b3faefdb84aabc694ee89732dbb2eb5e' => 
    array (
      0 => '/var/www/mvc2/views/index/index.tpl',
      1 => 1366497578,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '232487559538476a90c2651-32607364',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_538476a90c3930_17411327',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_538476a90c3930_17411327')) {function content_538476a90c3930_17411327($_smarty_tpl) {?>Hola desde la vista smarty...<?php }} ?>