<?php /* Smarty version Smarty-3.1.8, created on 2014-10-03 08:54:35
         compiled from "/var/www/proindusquim/views/automotriz/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:101973824154048d3826d809-08487297%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ca607eb9e2ef53d6a546f3b3af33cdb1ede0fdcd' => 
    array (
      0 => '/var/www/proindusquim/views/automotriz/index.tpl',
      1 => 1412344469,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '101973824154048d3826d809-08487297',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_54048d382ba5f9_72892181',
  'variables' => 
  array (
    '_layoutParams' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_54048d382ba5f9_72892181')) {function content_54048d382ba5f9_72892181($_smarty_tpl) {?><!-- inicio slider en todas las páginas -->
<div id="banner_principal">
</div>
<!-- fin slider en todas las páginas-->
</div>
<!-- fin contenedor de layout de trabajo que viene del template-->
<!-- inicio contenedor noticias -->
<div id="contenedor_contenido_dinamico">
    <!-- inicio noticias página principal -->
    <div id="noticias_proindusquim">
        <div id="barra_productos">
            <!-- inicio sección descripción productos izquierda-->
            <div id="barra_productos_izquierda">
                <ul class="youtube-videogallery">
                    <li><a href="https://www.youtube.com/watch?v=F6lq2HDBs14">Línea Automotriz</a></li>
                </ul>
                <!-- Inicio script funcionamiento videos -->
                <script>
                    
                    $(document).ready(function(){
                        $("ul.youtube-videogallery").youtubeVideoGallery( {plugin:'fancybox'} );
                    });
                    
                </script>
                <!--Fin script funcionamiento videos-->                
            </div>    
            <!-- inicio sección descripción productos derecha-->
            <div id="barra_productos_derecha">
                <div class="left-footer-productos">
                    <div class="cuadro_productos">
                        <div class="centrado bloque_titulos subtitulo-4 blanco">CHAMPU</div>
                        <div class="descripcion_productos">
                            <p><b class="rojo">Descripción:</b><br/>Champú de autos alta espuma con efecto abrillantador. </p><br/>
                            <p><b class="rojo">Usos:</b><br/>Lavado manual o con máquina de todo tipo de vehículos y transporte.</p><br/>
                            <p><b class="rojo">Dilución:</b><br/>1-2 medida por litro de agua.</p><br/>
                            <p><b class="rojo">Precauciones:</b><br/>Utilizar Guantes de caucho</p><br/>
                            <p><a href="<?php echo $_smarty_tpl->tpl_vars['_layoutParams']->value['root'];?>
public/files/automotriz_fichas/CHAMPU_FCF.pdf""><b class="rojo">DESCARGAR FICHA TÉCNICA</b></a></p><br/>
                        </div>
                        <div class="imagen_productos">
                            <img src="<?php echo $_smarty_tpl->tpl_vars['_layoutParams']->value['root'];?>
views/automotriz/img/champu.jpg" />
                            <div class="valores_presentacion"><b class="bloque_titulos blanco">Presentación:</b><br/><div class="cuadro_presentacion">500 ml</div> <div class="cuadro_presentacion">1 lt</div> <div class="cuadro_presentacion">4 lt</div><div class="cuadro_presentacion">20 lt</div><div class="cuadro_presentacion">220 lt</div></div>
                        </div>
                    </div>
                </div>
                <div class="left-footer-productos">
                    <div class="cuadro_productos">
                        <div class="centrado bloque_titulos subtitulo-4 blanco">CERA</div>
                        <div class="descripcion_productos">
                            <p><b class="rojo">Descripción:</b><br/>Cera protectora de alto brillo con protector UV que evita el resecamiento acelerado de la pintura.</p><br/>
                            <p><b class="rojo">Usos:</b><br/>Carrocerías y cromados.</p><br/>
                            <p><b class="rojo">Dilución:</b><br/>Uso directo.</p><br/>
                            <p><b class="rojo">Precauciones:</b><br/>Utilizar Guantes de caucho</p><br/>
                            <p><a href="<?php echo $_smarty_tpl->tpl_vars['_layoutParams']->value['root'];?>
public/files/automotriz_fichas/CERA_FCF.pdf""><b class="rojo">DESCARGAR FICHA TÉCNICA</b></a></p><br/>
                        </div>
                        <div class="imagen_productos">
                            <img src="<?php echo $_smarty_tpl->tpl_vars['_layoutParams']->value['root'];?>
views/automotriz/img/cera.jpg" />
                            <div class="valores_presentacion"><b class="bloque_titulos blanco">Presentación:</b><br/><div class="cuadro_presentacion">500 ml</div> <div class="cuadro_presentacion">1 lt</div> <div class="cuadro_presentacion">4 lt</div><div class="cuadro_presentacion">20 lt</div></div>
                        </div>
                    </div>
                </div>
                <div class="left-footer-productos">
                    <div class="cuadro_productos">
                        <div class="centrado bloque_titulos subtitulo-4 blanco">LIMPIADOR MULTIUSO</div>
                        <div class="descripcion_productos">
                            <p><b class="rojo">Descripción:</b><br/>Liquido limpiador desengrasante y restaurador.</p><br/>
                            <p><b class="rojo">Usos:</b><br/>Paneles, plástico y tapicería.</p><br/>
                            <p><b class="rojo">Dilución:</b><br/>Uso directo sin diluir.</p><br/>
                            <p><b class="rojo">Precauciones:</b><br/>Utilizar Guantes de caucho</p><br/>
                            <p><a href="<?php echo $_smarty_tpl->tpl_vars['_layoutParams']->value['root'];?>
public/files/automotriz_fichas/LIMPIADOR_MULTIUSO_FCF.pdf""><b class="rojo">DESCARGAR FICHA TÉCNICA</b></a></p><br/>
                        </div>
                        <div class="imagen_productos">
                            <img src="<?php echo $_smarty_tpl->tpl_vars['_layoutParams']->value['root'];?>
views/automotriz/img/limpiadormultiuso.jpg" />
                            <div class="valores_presentacion"><b class="bloque_titulos blanco">Presentación:</b><br/><div class="cuadro_presentacion">500 ml</div> <div class="cuadro_presentacion">1 lt</div> <div class="cuadro_presentacion">4 lt</div><div class="cuadro_presentacion">20 lt</div></div>
                        </div>
                    </div>
                </div>
                <div class="left-footer-productos">
                    <div class="cuadro_productos">
                        <div class="centrado bloque_titulos subtitulo-4 blanco">SILICON PROTECTOR</div>
                        <div class="descripcion_productos">
                            <p><b class="rojo">Descripción:</b><br/>Protector y abrillantador siliconado con fragancia, protege de rayos UV evitando el resecamiento y rotura.</p><br/>
                            <p><b class="rojo">Usos:</b><br/>Plástico, vinil, caucho y cuero.</p><br/>
                            <p><b class="rojo">Dilución:</b><br/>Uso directo sin diluir.</p><br/>
                            <p><b class="rojo">Precauciones:</b><br/>---</p><br/>
                            <p><a href="<?php echo $_smarty_tpl->tpl_vars['_layoutParams']->value['root'];?>
public/files/automotriz_fichas/SILICON_PROTECTOR_FCF.pdf""><b class="rojo">DESCARGAR FICHA TÉCNICA</b></a></p><br/>
                        </div>
                        <div class="imagen_productos">
                            <img src="<?php echo $_smarty_tpl->tpl_vars['_layoutParams']->value['root'];?>
views/automotriz/img/siliconprotector.jpg" />
                            <div class="valores_presentacion"><b class="bloque_titulos blanco">Presentación:</b><br/><div class="cuadro_presentacion">500 ml</div> <div class="cuadro_presentacion">1 lt</div> <div class="cuadro_presentacion">4 lt</div><div class="cuadro_presentacion">20 lt</div><div class="cuadro_presentacion">220 lt</div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- fin sección descripción productos-->
    </div>
</div>
<!-- fin contenedor noticias dinámico -->
<!-- inicio menú íconos -->
<div id="menu_iconos">
    <!-- inicio sección descripción productos-->
    <div id="barra_productos">
        <div id="barra_iconos">
            <div class="cuadrado">
                <a href="automotriz"><div class="boton_icono boton_automotriz"></div></a>
                <a href="industrial"><div class="boton_icono boton_industrial"></div></a>
                <a href="construccion"><div class="boton_icono boton_construccion"></div></a>                      
                <a href="institucional_hogar"><div class="boton_icono boton_hogar"></div></a>  
            </div>    
        </div>            
    </div>
    <!-- fin sección descripción productos-->
</div> <?php }} ?>