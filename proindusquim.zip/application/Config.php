<?php

/*
 * -------------------------------------
 * www.dlancedu.com | Jaisiel Delance
 * framework mvc basico
 * Config.php
 * -------------------------------------
 */


define('BASE_URL', 'http://localhost/proindusquim/');
define('DEFAULT_CONTROLLER', 'index');
define('DEFAULT_LAYOUT', 'default');

define('APP_NAME', '');
define('APP_SLOGAN', '');
define('APP_COMPANY', '');
define('SESSION_TIME',10 );
define('HASH_KEY', '4f6a6d832be79');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'medusa');
define('DB_NAME', 'proindusquim');
define('DB_CHAR', 'utf8');

?>
